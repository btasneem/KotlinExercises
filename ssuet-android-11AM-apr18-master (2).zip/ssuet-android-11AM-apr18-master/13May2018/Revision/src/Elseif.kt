fun main(args: Array<String>) {

    if (true && false) {
        println("in first if block")
    } else if (true || false) {
        println("in else if block")

    } else {
        println("in else block")

    }

}