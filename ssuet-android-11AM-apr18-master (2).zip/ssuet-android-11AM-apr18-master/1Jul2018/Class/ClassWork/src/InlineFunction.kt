fun main(args: Array<String>) {
    println(sum(1,2))
}


fun sum(a:Int,b:Int) = a+b


fun getLength() = 10