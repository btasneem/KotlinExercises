fun main(args: Array<String>) {


    var name :String? = readLine()

    var name2 : String = name!!

    println(name2.length)

    println(
            name.substring(2))

    var name3 : String? = "hello"

    println(name3!![3])


    var Name :String = "aasam"

    println(Name.substring(0,5))




}