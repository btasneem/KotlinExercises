fun main(args: Array<String>) {

    println("please enter your name")
    var name = readLine()

    var age = 12

    println("your name is $name")

    println("your name is $name $age and age is $age")

    println("$age $name")
    println(age.toString()+name)


    var a = 10
    var b = "20"


    println("${a + b.toInt()} $name")

    var num = 23
    var decimal = 34.34

    println(num+decimal)

    var store = num+decimal





}