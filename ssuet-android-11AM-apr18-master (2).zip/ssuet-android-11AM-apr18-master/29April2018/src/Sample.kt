fun main(args: Array<String>) {
    var num1:Int = 10
    var num2:Float = 1.2f
    var numDouble:Double = 20.0
    var numLong:Long = 10L

    var hello:Int = 10
    hello = 20

    val fixedNum:Int = 10

    var myname = "Ishaq"

    var numWithoutType = 10

    var myChr:Char = 'A'

    print(numWithoutType)
}