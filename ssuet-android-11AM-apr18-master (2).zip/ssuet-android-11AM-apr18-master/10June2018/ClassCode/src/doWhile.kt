fun main(args: Array<String>) {

    do{
        var myBoolean = true

        println("Enter Value to Continue")

        if (readLine()!!.equals("quit")){
            myBoolean = false

        }

    }while (myBoolean)





}