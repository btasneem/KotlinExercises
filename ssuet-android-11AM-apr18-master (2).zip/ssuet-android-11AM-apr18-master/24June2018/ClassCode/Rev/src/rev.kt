fun main(args: Array<String>) {
   var a =  true

    while (a){
        println("hello world")

        if (readLine()!! == "yes") {

            a = false

        }
    }

    var number = 0

    while (number <=3){
        println("in loop")
        number++
    }




}