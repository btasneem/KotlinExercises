fun main(args: Array<String>) {

    var array1 = arrayOf(1,2,4,5)

    arrayOf(3,3,3,2,3,3,3,3,3,3)
    var array2 = Array<String>(10,{index->
        if(index==3)""
        else ""
    })

}