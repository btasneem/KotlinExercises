fun main(args: Array<String>) {
    val tableOf = 2
    val tableLength = 10
    for(tableVal in 1..tableLength)
    {
        println("$tableOf X $tableVal = ${tableOf*tableVal}")
    }

    println("${100F/2F}")
}