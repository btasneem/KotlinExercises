fun main(args: Array<String>) {

    val products  = {
        ""
    }
    val product1 = fun (){}

//    product1()

    val product = {x:Int,y:Int -> x*y}



    val product2 : (Int,Int)->Int={
        x,y->x*y
    }




}