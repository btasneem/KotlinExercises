fun main(args: Array<String>) {

    var name = "arbaz"

    var name2 = "arbaz"

    if (name == name2){
        println("name is available")
    }else{
        println("name is not available")
    }

    if (name.equals("rameez")){
        println("name is available")
    }else{
        println("name is not available")
    }
}