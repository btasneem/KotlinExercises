fun main(args: Array<String>) {



    var age = 12

    var condition: Boolean = age <= 14

    println(condition)

    if (condition) {
        println("this is true")
    } else {
        println("this is false")
    }

}