//fun keyword
// name main
//
fun main(args: Array<String>) {
    println("hello world")

    var name1 = "arbaz"
    var _name = "ishaq"
    var myName = "name"

    var strinAmount = "1,000"

    var intAmount  = 1_000_000_000L

    println(strinAmount)
    println(intAmount)

    println(intAmount+1)

    println(name1+" are "+_name+" "+myName+" "+intAmount)

    println("$name1 $_name are $myName $intAmount")


}
